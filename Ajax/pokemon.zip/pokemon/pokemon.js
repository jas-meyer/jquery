//var output=""
/*for(var i = 2; i < 152; i++){
	output+= "<img src=https://pokeapi.co/media/img/"+[i]+".png>"
}
//console.log(output);
//$('wrapper').append(output);

function addimg{
$('#wrapper').append("<img src=https://pokeapi.co/media/img/"+[i]+".png>")
}
for(var i = 2; i < 152; i++){
	output = "<img src=https://pokeapi.co/media/img/"+[i]+".png>"
}
*/
$(document).ready(function(){
//$('#wrapper').click(function(){
	for(var i = 1; i < 152; i++){
	$('#wrapper').append("<img src=https://pokeapi.co/media/img/"+[i]+".png>")
}
//});

});
//$function();