$(document).ready(function(){
	$('div img:nth-child(2)').click(function(){
		$('div img:nth-child(2)').hide();
	})
	$('div img:nth-child(3)').click(function(){
		$('div img:nth-child(3)').hide();
	})
	$('div img:nth-child(4)').click(function(){
		$('div img:nth-child(4)').hide();
	})
	$('div img:nth-child(5)').click(function(){
		$('div img:nth-child(5)').hide();
	})
	$('div img:nth-child(6)').click(function(){
		$('div img:nth-child(6)').hide();
	})
	$('div img:nth-child(7)').click(function(){
		$('div img:nth-child(7)').hide();
	})
	$('div img:nth-child(8)').click(function(){
		$('div img:nth-child(8)').hide();
	})
	$('div img:nth-child(9)').click(function(){
		$('div img:nth-child(9)').hide();
	})
	$('button').click(function(){
		location.reload();
	
	})

});